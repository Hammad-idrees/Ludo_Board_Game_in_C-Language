#include <iostream>
#include <pthread.h>
#include <cstdlib>  // For rand() and srand()
#include <ctime>    // For time()
#include <limits>   // For numeric_limits
#include "game_utils.h"
#include "player_threads.h"
#include <vector>
#include <algorithm>  // For std::shuffle
#include <random>     // For std::random_device and std::mt19937
#include<unistd.h>
#include<semaphore.h>
// Function to print a decorative line for the menu
void printTitle(const std::string &title) {
    const int totalWidth = 50;
    int padding = (totalWidth - title.length() - 4) / 2;

    // Print top border
    std::cout << std::string(totalWidth, '=') << std::endl;

    // Print title with padding
    std::cout << "||" << std::string(padding, ' ') << title
              << std::string(totalWidth - title.length() - padding - 4, ' ') << "||" << std::endl;

    // Print bottom border
    std::cout << std::string(totalWidth, '=') << std::endl;
}
// Function to display a colorful menu with borders and interactive input
void displayMenu(int &numPlayers, int &numTokens) {
    bool validInput = false;

    // Colors (if terminal supports ANSI escape codes)
    const std::string GREEN = "\033[32m";
    const std::string YELLOW = "\033[33m";
    const std::string RESET = "\033[0m"; // Reset to default

    while (!validInput) {
        clearScreen();

        // Title of the menu
        printTitle("WELCOME TO LUDO GAME SETUP");

        // Get number of players (2-4)
        std::cout << GREEN << "Enter number of players (2-4): " << RESET;
        std::cin >> numPlayers;

        if (std::cin.fail() || numPlayers < 2 || numPlayers > MAX_PLAYERS) {
            std::cin.clear();  // Clear error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Discard invalid input
            clearScreen();
            std::cout << YELLOW << "Invalid input! Please enter a number between 2 and 4." << RESET << std::endl;
        } else {
            validInput = true;
        }
    }

    validInput = false;  // Reset for token input validation

    // Get number of tokens (1-4)
    while (!validInput) {
        std::cout << GREEN << "Enter number of tokens per player (1-4): " << RESET;
        std::cin >> numTokens;

        if (std::cin.fail() || numTokens < 1 || numTokens > MAX_TOKENS) {
            std::cin.clear();  // Clear error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // Discard invalid input
            clearScreen();
            std::cout << YELLOW << "Invalid input! Please enter a number between 1 and 4." << RESET << std::endl;
        } else {
            validInput = true;
        }
    }

    clearScreen();  // Clear screen after setup is complete
}


int getNextTurn(Player players[], int numPlayers) {
    static std::vector<int> playerOrder;  // Keeps the randomized player order across rounds
    static int currentTurnIndex = 0;
    static bool isFirstCall = true;
    if (currentTurnIndex >= numPlayers || isFirstCall) {
        // Clear the previous order and shuffle the player indices
        playerOrder.clear();
        for (int i = 0; i < numPlayers; i++) {
            playerOrder.push_back(i);
        }
        // Shuffle the player order for randomness
        std::random_device rd;
        std::mt19937 gen(rd());  // Random number generator
        std::shuffle(playerOrder.begin(), playerOrder.end(), gen);  // Shuffle the order
        cout << endl;
        currentTurnIndex = 0;  // Reset the turn index for the new round
        isFirstCall = false;  // Prevent reinitializing after the first call
      //  cout << "Previous sequence: ";
  //      for (int i=0;i<numPlayers;i++) {
    //        cout << playerOrder[i]+1 << " ";
      //  }
  //      pressAnyKey();

    }
    // Get the next player to take their turn
    int val = playerOrder[currentTurnIndex] + 1;  // Return 1-based player index
    currentTurnIndex++;  // Move to the next player in the order
    return val;
}

// Reset color
const std::string RESET_COLOR = "\033[0m";

// Function to assign colors and create players
void createPlayers(Player players[], int numPlayers, int numTokens) {
    for (int i = 0; i < numPlayers; i++) {
        char colorSymbol = PLAYER_COLORS[i][2];  // Symbol for the player's token (one character)
        std::string playerColor = PLAYER_COLORS[i];  // Get the actual ANSI color code
        // Create player with the color symbol, number of tokens, color, and house number
        players[i] = Player(colorSymbol, numTokens, i);
    }
}
void cancelThread(int playerIndex) {
    cv.notify_all();  // Notify other threads to update their state
}
void displayCanncelled() {
    cout << "Cancelled Threads Are Shown Below: "<<endl;
    for (int i=0; i < MAX_PLAYERS; i++) {
        if (!players[i].is_active) {
            cout << "Player Id: "<<players[i].house<< endl;
        }
    }
}
bool anyPlayerHasActiveToken(Player players[], int numPlayers) {
    for (int i = 0; i < numPlayers; i++) {
        for (int j = 0; j < players[i].num_of_tokens; j++) {
            // Check if any token is still open and not at home
            if (players[i].tokens[j].is_open && !players[i].tokens[j].is_at_home) {
                return true;
            }
        }
    }
    return false; // All tokens are either closed or at home
}

// Master thread function
// Master thread function (manages game flow and player turns)
void* master_thread(void* arg) {
    int ct=0;
    int numPlayers = 2, numTokens = 2;  // Default values, can be overridden by the menu
    displayMenu(numPlayers, numTokens);

    // Create player objects
    createPlayers(players, numPlayers, numTokens);
    initializeGrid(players, numPlayers, numTokens);
    // Create worker threads for each player
    pthread_t playerThreads[MAX_PLAYERS];
    for (int i = 0; i < numPlayers; i++) {
        if (pthread_create(&playerThreads[i], nullptr, player_thread, (void*)&players[i]) != 0) {
            std::cerr << "Error creating player thread for Player " << i + 1 << std::endl;
        }
    }

    // Assign turns to the players in sequence
    for (int i = 0; i < 100; i++) {
        {
            int temp;
            std::lock_guard<std::mutex> lock(mtx);  // Lock the mutex to modify the shared turn variable
            temp = getNextTurn(players, numPlayers);  // Assign the turn to the next player
          Player *tempPlayer = getPlayer(temp);
            if (tempPlayer->is_active) {
                if (tempPlayer->hit_rate>=1) {
                   updateIsAllow(true,tempPlayer->house);
                    cv.notify_all();
                }

                turn=temp;  // Assign turn if player is active
            } else {
                cancelThread(temp-1);  // Cancel thread if player is inactiv
        }
        }
        cv.notify_all();  // Notify all waiting threads
        usleep(3000);
    }
    gameOver=true;
    cv.notify_all();

    // Wait for all player threads to finish
    for (int i = 0; i < numPlayers; i++) {
        pthread_join(playerThreads[i], nullptr);
    }
    pressAnyKey();
    clearScreen();
    cout << "Complete Summary Of Game Shown Below "<<endl;
    displayCanncelled();
    pressAnyKey();
    return nullptr;
}


int main() {
    // Seed the random number generator for dice rolls
    srand(time(nullptr));

    // Create the master thread
    pthread_t masterThread;
    pthread_create(&masterThread, nullptr, master_thread, nullptr);

    // Wait for the master thread to finish
    pthread_join(masterThread, nullptr);

    return 0;
}