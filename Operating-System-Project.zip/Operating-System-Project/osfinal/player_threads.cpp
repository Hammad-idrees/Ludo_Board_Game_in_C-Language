#include "player_threads.h"
#include"game_utils.h"
#include <stdlib.h>
using namespace  std;
#include <unistd.h>
#include<thread>
#include<termios.h>
void move(Token &obj,Player *&player);
void moveLiveToken(Player *&player) {
    int choice;
    Token& temp=player->displayOpen();
    move(temp,player);
}
int circular_path_row1[] = {6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7};
int circular_path_column1[]={1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 1, 2, 3, 4, 5};
//   Get the length of the array
int circular_path_row2[] = {1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 1, 2, 3, 4, 5};
int circular_path_column2[]={8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7};
int circular_path_row3[] = {13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 13, 12, 11, 10, 9};
int circular_path_column3[] = {6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 7, 7, 7, 7, 7};

int circular_path_row4[] = {8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 14, 13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7};
int circular_path_column4[] = {13, 12, 11, 10, 9, 8, 8, 8, 8, 8, 8, 7, 6, 6, 6, 6, 6, 6, 5, 4, 3, 2, 1, 0, 0, 0, 1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6, 7, 8, 8, 8, 8, 8, 8, 9, 10, 11, 12, 13, 14, 14, 13, 12, 11, 10, 9};
static bool thisTurnKill=false;
// Function to update the game grid with player symbol
int findIndex(int x, int y, char symbol) {
    int index = -1;  // Default index if not found

    // Based on the symbol, use the appropriate row and column arrays
    if (symbol == '1') {
        // Use row 1 and column 1
        for (int i = 0; i < 64; i++) {
            if (circular_path_row1[i] == x && circular_path_column1[i] == y) {
                index = i;
                break;
            }
        }
    }
    else if (symbol == '2') {
        // Use row 2 and column 2
        for (int i = 0; i < 64; i++) {
            if (circular_path_row2[i] == x && circular_path_column2[i] == y) {
                index = i;
                break;
            }
        }
    }
    else if (symbol == '3') {
        // Use row 3 and column 3
        for (int i = 0; i < 64; i++) {
            if (circular_path_row3[i] == x && circular_path_column3[i] == y) {
                index = i;
                break;
            }
        }
    }
    else if (symbol == '4') {
        // Use row 4 and column 4
        for (int i = 0; i < 64; i++) {
            if (circular_path_row4[i] == x && circular_path_column4[i] == y) {
                index = i;
                break;
            }
        }
    }

    return index;  // Return the index if found, or -1 if not
}
void returnToken(char symbol) {
    // Define coordinates for each player's tokens
    int playerTokens[4][4][2] = {
        {{0, 0}, {0, 5}, {5, 0}, {5, 5}},    // Player 1's tokens
        {{0, 9}, {0, 14}, {5, 9}, {5, 14}},  // Player 2's tokens
        {{9, 0}, {9, 5}, {14, 0}, {14, 5}},  // Player 3's tokens
        {{9, 9}, {9, 14}, {14, 9}, {14, 14}} // Player 4's tokens
    };

    // Determine the player index (symbol '1' corresponds to index 0, etc.)
    int playerIndex = symbol - '1';

    // Iterate through the player's token coordinates and update the grid
    for (int i = 0; i < 4; i++) {
        int row = playerTokens[playerIndex][i][0];
        int col = playerTokens[playerIndex][i][1];
        if (game_grid[row][col] == '*') {
            game_grid[row][col] = symbol;
            break;  // Stop after updating the first valid token
        }
    }
}

void viewHitRate(Player *&player) {
    cout << "Your Current Kill Counts: " << player->hit_rate << endl;
}
bool sameExist(int x,int y,char symbol) {
    if (game_grid[x][y] == symbol) {return true;}
    else {return false;}
}
bool diffExist(int x,int y,char symbol) {
    if ((game_grid[x][y] != symbol)&&(game_grid[x][y]!='0')) {return true;}
    else {return false;}
}

std::mutex tokenMutex; // Mutex to synchronize access to token state
void setTokenPosition(Player*& obj, Token& token, int newX, int newY, char houseSymbol) {
    std::lock_guard<std::mutex> lock(tokenMutex);  // Lock mutex to ensure exclusive access to shared resource

    if (sameExist(newX, newY, token.symbol)) {
        cout << "Player: " << token.symbol << " you already have "
             << obj->getBlockToken(newX, newY, token.symbol)
             << " existing token there, making block.\n";
        token.x = newX;
        token.y = newY;
        token.setIsBlock(true);
    }
    else if (diffExist(newX, newY, token.symbol)) {
        Token& temp = getTokenByCoordinate(newX, newY);  // Ensure you're working with a reference
        if (temp.isBlock) {
            cout << "Sorry, there is a block at this location You Cant Move." << endl;
        }

        else {

            cout << "Player: " << token.symbol << " You have killed Player: " << temp.symbol << endl;
            thisTurnKill=true;
            obj->hit_rate++;
            viewHitRate(obj);
            returnToken(temp.symbol);
            game_grid[newX][newY] = houseSymbol;
            temp.is_open = false;  // Mark the token as dead
            temp.x=0;
            temp.y=0;
            cout << "Token placed at coordinates: " << newX << ":" << newY << "\n";
            token.x = newX;
            token.y = newY;
            pressAnyKey();
        }
    }
    else {
        if (isHomePosition(newX,newY)) {
            cout << "Congrats Reached Home...."<<endl;
            pressAnyKey();
        }
            game_grid[newX][newY] = houseSymbol;
            cout << "Token placed at coordinates: " << newX << ":" << newY << "\n";
            token.x = newX;
            token.y = newY;
    }
    pressAnyKey();

}
void makeTokenLive(Player*& obj) {
    try {
        Token& token = obj->getDeadTokenCoordinate();  // Get reference to the dead token
        token.is_open = true;

        // Clear the previous token position
        game_grid[token.x][token.y] = '*';

        // Set the token's new position based on the player's house
        switch (obj->house) {
            case 1:
                setTokenPosition(obj, token, 6, 1, '1');
            break;
            case 2:
                setTokenPosition(obj, token, 1, 8, '2');
            break;
            case 3:
                setTokenPosition(obj, token, 13, 6, '3');
            break;
            case 4:
                setTokenPosition(obj, token, 8, 13, '4');
            break;
            default:
                cout << "Invalid house number." << endl;
            break;
        }
    }
    catch (const std::runtime_error& e) {
        cout << e.what() << endl;
        pressAnyKey();
    }
}

bool checkHome(Token &obj) {
    if (obj.symbol == '1') {
        if ((obj.y+dice_value==6)&& (obj.x==7)) {
            return true;
        }
    }
    else if (obj.symbol == '2') {
        if ((obj.x+dice_value==6)&&(obj.y==7)) {
            return true;
        }
    }
    else if (obj.symbol == '3') {
        if ((obj.y==7)&&(obj.x-dice_value==8)) {
            return true;
        }
    }
    else if (obj.symbol == '4') {
        if ((obj.y-dice_value==8)&&(obj.x==7)) {
            return true;
        }
    }

    return  false;
}
void revertToken(Player*& obj, Token& token,char symbol) {
    game_grid[token.x][token.y]='0';
    if (symbol == '1') {
        setTokenPosition(obj,token, 6,1, symbol);
    }
    else if (symbol == '2') {
        setTokenPosition(obj,token, 1,8, symbol);
    }
    else if (symbol == '3') {
        setTokenPosition(obj,token, 13,6, symbol);
    }
    else if (symbol == '4') {
        setTokenPosition(obj,token, 8,13, symbol);
    }
}
void move(Token &obj,Player *&player) {
    int index = -1;
    int x, y;

    int *circular_path_row;
    int *circular_path_column;
if (obj.symbol=='1') {
circular_path_row = circular_path_row1;
    circular_path_column = circular_path_column1;
}
    else if (obj.symbol=='2') {
        circular_path_row = circular_path_row2;
        circular_path_column = circular_path_column2;
    }
    else if (obj.symbol=='3') {
        circular_path_row = circular_path_row3;
        circular_path_column = circular_path_column3;
    }
    else if (obj.symbol=='4') {
        circular_path_row = circular_path_row4;
        circular_path_column = circular_path_column4;
    }
    int length = 56;  // Since each circular path array has 56 elements

    // Find the current position of the token
    for (int i = 0; i < length; i++) {
        if (obj.x == circular_path_row[i] && obj.y == circular_path_column[i]) {
            index = i;
            break;
        }
    }

    // If the current position is found
    if (index != -1) {
        // Calculate new position based on dice_value
        int newIndex = index + dice_value;

        if (newIndex>=length) {
            if (checkHome(obj)) {
                if (checkIsAllow(obj.symbol)) {
                    cout <<"Token Reach Home Conrats...\n";
    /////////////to dooo
        ///
    if (!player->isPlaceBlock(obj.x,obj.y,obj.symbol)) {
        game_grid[obj.x][obj.y] = '0';  // Clear the current position
    }
        player->clearBlockPrev(obj.x,obj.y,obj.symbol);
                    obj.x=0;
                    obj.y=0;

                    obj.reached();
                }
                else {
                    cout << "Sorry You Are Not Eligible To Pass "<<endl;
                }
            }
            else {

                cout << "You need exact numbers to pass sorry!"<<endl;
            }
            pressAnyKey();
        }
        else {
            x = circular_path_row[newIndex];
            y = circular_path_column[newIndex];
            if (!player->isPlaceBlock(obj.x,obj.y,obj.symbol)) {
                if (findIndex(x,y,obj.symbol)>=51) {
                    if (checkIsAllow(obj.symbol)) {
                        game_grid[obj.x][obj.y] = '0';
                        // Get the new x and y coordinates
                        setTokenPosition(player,obj, x, y,obj.symbol);
                    }
                    else {
                        cout << "Sorry You Are Not Allowed To Enter.."<<endl;
                        cout << "Your Token Will Reveterted To Spawn Position"<<endl;
                        revertToken(player,obj,obj.symbol);
                        pressAnyKey();
                    }
                }
                else {
                    game_grid[obj.x][obj.y] = '0';
                    // Get the new x and y coordinates
                    setTokenPosition(player,obj, x, y,obj.symbol);
                }
            }
            else {
                player->clearBlockPrev(obj.x,obj.y,obj.symbol);
                setTokenPosition(player,obj, x, y,obj.symbol);
            }
        }
    } else {
        cout << "Error: Token position not found." << endl;
    }
}
void special(Player *&obj) {
int choice=0;
    cout << "1:Move Existing Token"<<endl;
    cout << "2:Add New Token"<<endl;
    cout << "Choice: ";
    cin>>choice;
    if (choice==1){
        Token& temp=obj->displayOpen();
        cout << endl;
        move(temp,obj);
    }
    else if (choice==2) {
        makeTokenLive(obj);
    }

}

void play(Player *&player) {
    int house = player->house;
    bool isSixStreak=false;
    int t1;
    int t2;
    static int count=0;

    std::unique_lock<std::mutex> lock(mtx);  // Lock the mutex to safely access shared data

    while (!gameOver) {
        // Continue playing until the game is over

        thisTurnKill=false;
        // Wait until the admin assigns this player's turn or the game is over
        cv.wait(lock, [house] { return turn == house || gameOver; });
        // If the game is over, break out of the loop immediately
        if (gameOver) {
            break;
        }
        rollDice();
        if (!isSixStreak) {
            if (dice_value==6) {
                rollDice();
                t1=dice_value;
                rollDice();
                t2=dice_value;
                if (t1==6 && t2==6) {
                    cout << "3 CONSECUTIVE SIXES TURN SKIPPED!!"<<endl;
                    pressAnyKey();
                    turn=-1;
                    cv.notify_all();
                }
                else {
                    dice_value=6;
                    isSixStreak=true;
                    count++;
                }
            }
        }
        else {
            if (count==1) {
                dice_value=t1;
            }
            else if (count==2 && t1==6) {
                dice_value=t2;
            }
            else if (count==2 && t1!=6) {
                count=0;
                isSixStreak=false;
                turn=-1;
                cv.notify_all();  // Notify all players that they can wait for the next turn
                continue;
            }
           else if (count==3) {
               count=0;
               isSixStreak=false;
               turn=-1;
               cv.notify_all();  // Notify all players that they can wait for the next turn
               continue;
           }
                count++;
        }
        printGrid();
        cout << "Player Number : "<<house<<" Rolled Dice Got: "<<dice_value<<" "<<endl;;;
        if (dice_value != 6 && !player->anytokenOpen()) {
            cout << "Turn Skipped No Token Open ";
        } else if (dice_value != 6 && player->anytokenOpen()) {
            moveLiveToken(player);
        } else if (dice_value == 6 && !player->anytokenOpen()) {
            makeTokenLive(player);
        } else {
            special(player);
        }
            inactiveCheck(player->house,dice_value,thisTurnKill,player);
        // Reset turn so the player cannot act again until the admin sets the next turn
        fflush(stdout);

        if (!isSixStreak) {
            turn = -1;
        }
        pressAnyKey();
        clearScreen();
        // Wait until the admin assigns the next turn
        cv.notify_all();  // Notify all players that they can wait for the next turn

    }
}
    void* player_thread(void* arg) {
        // Cast the argument to a Player object
        Player* player = static_cast<Player*>(arg);  // Use static_cast for better type safety

        // More game logic will go here...
        play(player);
        return nullptr;  // End the thread
    }

