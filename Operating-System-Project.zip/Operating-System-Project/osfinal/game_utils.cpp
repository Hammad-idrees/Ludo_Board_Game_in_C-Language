#include <iostream>
#include "game_utils.h"
#include "player_threads.h"
#define GREEN "\033[32m"
#define RESET "\033[0m"
#include <random>
#include <algorithm>
#include <chrono>
#include <array>
#include <thread>
#include<termios.h>
Player players[MAX_PLAYERS];  // This allocates memory for the array
 int ps1=0;
 int ps2=0;
 int ps3=0;
 int ps4=0;
bool p1allowed=false;
 bool p2allowed=false;
bool p3allowed=false;
 bool p4allowed=false;
int maxAllowedNoSix=40;
extern  void updateIsAllow(bool status,int symbol) {
    if (symbol == 1) {
     p1allowed=status;
    }
    else if (symbol == 2) {
        p2allowed=status;
    }
    else if (symbol == 3) {
        p3allowed=status;
    }
    else if (symbol == 4) {
     p4allowed=status;
    }
}
bool checkIsAllow(char symbol) {
    if (symbol == '1') {
        if (p1allowed) {
            return true;
        }
    }
    else if (symbol == '2') {
        if (p2allowed) {
            return true;
        }
    }
    else if (symbol == '3') {
        if (p3allowed) {
            return true;
        }
    }
    else if (symbol == '4') {
        if (p4allowed) {
            return true;
        }
    }
    return false;
}
bool isHomePosition(int x, int y) {
    // Player 1's house (top-left corner)
    if ((x == 0 && y == 0) || (x == 0 && y == 5) || (x == 5 && y == 0) || (x == 5 && y == 5)) {
        return true;
    }

    // Player 2's house (top-right corner)
    if ((x == 0 && y == 9) || (x == 0 && y == 14) || (x == 5 && y == 9) || (x == 5 && y == 14)) {
        return true;
    }

    // Player 3's house (bottom-left corner)
    if ((x == 9 && y == 0) || (x == 9 && y == 5) || (x == 14 && y == 0) || (x == 14 && y == 5)) {
        return true;
    }

    // Player 4's house (bottom-right corner)
    if ((x == 9 && y == 9) || (x == 9 && y == 14) || (x == 14 && y == 9) || (x == 14 && y == 14)) {
        return true;
    }

    // If no matching position is found, return false
    return false;
}

bool isSafe(int x, int y) {
    if ((x == 6 && y == 1) || (x == 1 && y == 8) ||
        (x == 13 && y == 6) || (x == 8 && y == 13)) {
        return true;
        }
    return false;
}
void   neutralizer(int symbol) {
    char symbolChar = '0' + symbol;
        for (int i=0;i<15;i++) {
            for (int j=0;j<15;j++) {
                if (symbolChar == game_grid[i][j]) {
                    if (isHomePosition(i,j)) {
                        game_grid[i][j] = '*';
                    }
                    else {
                        game_grid[i][j] = '0';
                    }
                }
            }
        }
}
void inactiveCheck(int symbol, int diceValue,bool kill,Player *&obj) {
    // If dice value is 6, reset the respective player's position to 0
    int check=0;
    if (diceValue == 6 || kill) {
        if (symbol == 1) {
            ps1 = 0;
        } else if (symbol == 2) {
            ps2 = 0;
        } else if (symbol == 3) {
            ps3 = 0;
        } else if (symbol == 4) {
            ps4 = 0;
        }
    } else {
        // If dice value is not 6, increment the respective player's position
        if (symbol == 1) {
            check=ps1++;

        } else if (symbol == 2) {
           check= ps2++;
        } else if (symbol == 3) {
           check= ps3++;
        } else if (symbol == 4) {
           check= ps4++;
        }
    }

    if (check >= maxAllowedNoSix) {
        cout << endl << "Player: "<<obj->house << " Will Be Removed Due To Inactivity"<<endl;
        neutralizer(symbol);
        obj->is_active = false;
        pressAnyKey();
    }
}

bool gameOver = false;  // Initially the game is not over
int validtokenpos[4][4]={{0,5,75,80},{9,14,84,89},{135,140,210,215},{144,149,219,224}};
char game_grid[15][15] = {0};  // 15x15 grid initialized to 0
int dice_value=0;
const std::string PLAYER_COLORS[] = {
    "\033[31m",  // Red (Player 1)
    "\033[32m",  // Green (Player 2)
    "\033[34m",  // Blue (Player 3)
    "\033[33m",  // Yellow (Player 4)
    "\033[36m",  // Cyan (for safe zones or other areas if needed)
    "\033[35m"   // Magenta (for any additional zones if needed)
};
void pressAnyKey() {
    termios oldt, newt;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
}
// Function definition
Token& getTokenByCoordinate(int x, int y) {
    for (int i = 0; i < MAX_PLAYERS; i++) {  // Loop through all players
        for (int j = 0; j < players[i].num_of_tokens; j++) {  // Loop through each player's tokens
            if (players[i].tokens[j].x == x && players[i].tokens[j].y == y) {
                return players[i].tokens[j];
            }
        }
    }
    throw std::runtime_error("No token found at the specified coordinates.");
}
Player *getPlayer(int symbol) {
    for (int i = 0; i < MAX_PLAYERS; i++) {
        if (players[i].house == symbol) {
            return &players[i];
        }
    }
}
void displayInactive() {
    cout << "Ps1: " << ps1 << endl;
    cout << "Ps2: " << ps2 << endl;
    cout << "Ps3: " << ps3 << endl;
    cout << "Ps4: " << ps4 << endl;
}
// Define and initialize global variables
std::condition_variable cv;
std::mutex mtx;
int turn = -1;  // Initialize turn to -1 (no player's turn initially)
bool enterHomePath(int x,int y,char symbol) {

}

void rollDice() {
    std::array<int, 6> diceFaces = {1, 2, 3, 4, 5, 6};  // Dice faces

    // Create a random number generator with seed based on current time
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::shuffle(diceFaces.begin(), diceFaces.end(), std::default_random_engine(seed));

    // Return the first value from the shuffled array
    dice_value= diceFaces[0];
}

// Function to clear the grid before initializing houses
int GRID_SIZE = 15;
void clearGrid() {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            game_grid[i][j] = '0';  // Empty cell
        }
    }
}

void clearScreen() {
#ifdef _WIN32
    system("cls"); // For Windows
#else
    system("clear"); // For macOS and Linux
#endif
}
void sleep(int sec) {
    std::this_thread::sleep_for(std::chrono::seconds(sec));  // Sleep for `sec` seconds
}


void placeToken(Player players[], int numoftoken, int numofplayer) {
    for (int i = 0; i < numofplayer; i++) {
        char symbol = players[i].tokens[0].symbol;  // Assuming each player uses the same symbol for all tokens

        // Check the house number for each player and place the tokens accordingly
        for (int j = 0; j < numoftoken; j++) {  // Loop through all tokens (should be 4 if numoftoken = 4)
            if (players[i].house == 1) {
                // Player 1's house (top-left corner)
                if (j == 0) {
                    game_grid[0][0] = symbol;
                    players[i].tokens[j].setCoordinates(0, 0);
                } else if (j == 1) {
                    game_grid[0][5] = symbol;
                    players[i].tokens[j].setCoordinates(0, 5);
                } else if (j == 2) {
                    game_grid[5][0] = symbol;
                    players[i].tokens[j].setCoordinates(5, 0);
                } else if (j == 3) {
                    game_grid[5][5] = symbol;
                    players[i].tokens[j].setCoordinates(5, 5);  // Added missing 4th token
                }
            } else if (players[i].house == 2) {
                // Player 2's house (top-right corner)
                if (j == 0) {
                    game_grid[0][9] = symbol;
                    players[i].tokens[j].setCoordinates(0, 9);
                } else if (j == 1) {
                    game_grid[0][14] = symbol;
                    players[i].tokens[j].setCoordinates(0, 14);
                } else if (j == 2) {
                    game_grid[5][9] = symbol;
                    players[i].tokens[j].setCoordinates(5, 9);
                } else if (j == 3) {
                    game_grid[5][14] = symbol;
                    players[i].tokens[j].setCoordinates(5, 14);  // Added missing 4th token
                }
            } else if (players[i].house == 3) {
                // Player 3's house (bottom-left corner)
                if (j == 0) {
                    game_grid[9][0] = symbol;
                    players[i].tokens[j].setCoordinates(9, 0);
                } else if (j == 1) {
                    game_grid[9][5] = symbol;
                    players[i].tokens[j].setCoordinates(9, 5);
                } else if (j == 2) {
                    game_grid[14][0] = symbol;
                    players[i].tokens[j].setCoordinates(14, 0);
                } else if (j == 3) {
                    game_grid[14][5] = symbol;
                    players[i].tokens[j].setCoordinates(14, 5);  // Added missing 4th token
                }
            } else if (players[i].house == 4) {
                // Player 4's house (bottom-right corner)
                if (j == 0) {
                    game_grid[9][9] = symbol;
                    players[i].tokens[j].setCoordinates(9, 9);
                } else if (j == 1) {
                    game_grid[9][14] = symbol;
                    players[i].tokens[j].setCoordinates(9, 14);
                } else if (j == 2) {
                    game_grid[14][9] = symbol;
                    players[i].tokens[j].setCoordinates(14, 9);
                } else if (j == 3) {
                    game_grid[14][14] = symbol;
                    players[i].tokens[j].setCoordinates(14, 14);  // Added missing 4th token
                }
            }
        }
    }
}

// Initialize the grid (setting up the board for 4 players)
// Function to initialize the grid dynamically based on the number of players and tokens
void initializeGrid(Player players[],int numofplayer,int numberoftoken) {
    // First, clear the entire grid to empty cells
    for (int i = 0; i < 15; i++) {
        for (int j = 0; j < 15; j++) {
            game_grid[i][j] = '0';  // Empty cell
        }
    }

    // Player 1 house (top-left corner)
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            game_grid[i][j] = '*';  // Mark as Player 1's house
        }
    }

    // Player 2 house (top-right corner)
    for (int i = 0; i < 6; i++) {
        for (int j = 9; j < 15; j++) {
            game_grid[i][j] = '*';  // Mark as Player 2's house
        }
    }

    // Player 3 house (bottom-left corner)
    for (int i = 9; i < 15; i++) {
        for (int j = 0; j < 6; j++) {
            game_grid[i][j] = '*';  // Mark as Player 3's house
        }
    }

    // Player 4 house (bottom-right corner)
    for (int i = 9; i < 15; i++) {
        for (int j = 9; j < 15; j++) {
            game_grid[i][j] = '*';  // Mark as Player 4's house
        }
    }
    placeToken(players,numberoftoken,numofplayer);
}
// Function to check if a cell is in a house and which player's house
int getHouseOwner(int row, int col) {
    // Player 1's house (top-left corner)
    if (row >= 0 && row < 6 && col >= 0 && col < 6) {
        return 1;
    }

    // Player 2's house (top-right corner)
    if (row >= 0 && row < 6 && col >= 9 && col < 15) {
        return 2;
    }

    // Player 3's house (bottom-left corner)
    if (row >= 9 && row < 15 && col >= 0 && col < 6) {
        return 3;
    }

    // Player 4's house (bottom-right corner)
    if (row >= 9 && row < 15 && col >= 9 && col < 15) {
        return 4;
    }

    return 0;  // Not in any house
}
#define RESET "\033[0m"
#define RED "\033[31m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"
#define BLUE "\033[34m"
//const std::string YELLOW =  "\033[33m";  // YELLOW color for 'O'
// Print the grid to the console
void printGrid() {
    for (int i = 0; i < 15; i++) {
        // Print the top border
        for (int j = 0; j < 15; j++) {
            std::cout << "+---";
        }
        std::cout << "+" << std::endl;

        // Print the grid cells
        for (int j = 0; j < 15; j++) {
            std::string color = RESET;

            // Home Areas (Red, Green, Blue, Yellow)
            if (i >= 0 && i < 6 && j >= 0 && j < 6) {            // Red Home (Top-left)
                color = PLAYER_COLORS[0];
            } else if (i >= 0 && i < 6 && j >= 9 && j < 15) {     // Green Home (Top-right)
                color = PLAYER_COLORS[1];
            } else if (i >= 9 && i < 15 && j >= 0 && j < 6) {     // Blue Home (Bottom-left)
                color = PLAYER_COLORS[2];
            } else if (i >= 9 && i < 15 && j >= 9 && j < 15) {    // Yellow Home (Bottom-right)
                color = PLAYER_COLORS[3];
            }

            // Spawn Points (Top-left Red Spawn = (0,0), Top-right Green Spawn = (0,14), etc.)
            else if ((i == 0 && j == 0) || (i == 0 && j == 14) || (i == 14 && j == 0) || (i == 14 && j == 14)) {
                // Spawn points (placeholders for spawn logic)
                if (i == 0 && j == 0) {
                    color = PLAYER_COLORS[0];  // Red spawn
                } else if (i == 0 && j == 14) {
                    color = PLAYER_COLORS[1];  // Green spawn
                } else if (i == 14 && j == 0) {
                    color = PLAYER_COLORS[2];  // Blue spawn
                } else if (i == 14 && j == 14) {
                    color = PLAYER_COLORS[3];  // Yellow spawn
                }
            }

            // Winning Paths for each player (based on your provided path)
            // Red Winning Path
            else if ((i == 6 && j == 1) || (i == 7 && j == 1) || (i == 7 && j == 2) || (i == 7 && j == 3) ||
                     (i == 7 && j == 4) || (i == 7 && j == 5) || (i == 7 && j == 6)) {
                color = PLAYER_COLORS[0];  // Red path
            }
            // Green Winning Path
            else if ((i == 1 && j == 8) || (i == 1 && j == 7) || (i == 2 && j == 7) || (i == 3 && j == 7) ||
                     (i == 4 && j == 7) || (i == 5 && j == 7) || (i == 6 && j == 7)) {
                color = PLAYER_COLORS[1];  // Green path
            }
            // Yellow Winning Path
            else if ((i == 7 && j == 8) || (i == 7 && j == 9) || (i == 7 && j == 10) || (i == 7 && j == 11) ||
                     (i == 7 && j == 12) || (i == 7 && j == 13) || (i == 8 && j == 13)) {
                color = PLAYER_COLORS[3];  // Yellow path
            }
            // Blue Winning Path
            else if ((i == 8 && j == 7) || (i == 9 && j == 7) || (i == 10 && j == 7) || (i == 11 && j == 7) ||
                     (i == 12 && j == 7) || (i == 13 && j == 7) || (i == 13 && j == 6)) {
                color = PLAYER_COLORS[2];  // Blue path
            }

            // Modify color based on the value on the grid ('1', '2', '3', '4')
            if (game_grid[i][j] == '1') {
                color = PLAYER_COLORS[0];  // Red for '1'
            } else if (game_grid[i][j] == '2') {
                color = PLAYER_COLORS[1];  // Green for '2'
            } else if (game_grid[i][j] == '3') {
                color = PLAYER_COLORS[2];  // Blue for '3'
            } else if (game_grid[i][j] == '4') {
                color = PLAYER_COLORS[3];  // Yellow for '4'
            }

            // Print the cell with the appropriate color
            std::cout << "| " << color << game_grid[i][j] << RESET << " ";
        }
        std::cout << "|" << std::endl;
    }

    // Print the bottom border
    for (int j = 0; j < 15; j++) {
        std::cout << "+---";
    }
    std::cout << "+" << std::endl;
}
