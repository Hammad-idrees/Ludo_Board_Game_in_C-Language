#ifndef PLAYER_THREADS_H
#define PLAYER_THREADS_H
#include<unistd.h>
#include <iostream>
#include "player_threads.h"
using namespace std;
// Token class definition
class Token {
public:
    // Attributes
    int value;    // Shows the token's value
    int x;        // X position of the token
    int y;        // Y position of the token
    bool is_open; // Indicates if the token is open (in play)
    bool is_at_home; // Indicates if the token is at home
    bool is_stopped; // Indicates if the token is stopped
    bool has_won; // Indicates if the token has reached the winning position
    char symbol;  // The symbol representing the token
    bool isBlock=false;
    // Default constructor
public:void reached() {
    is_at_home=true;
    is_open=false;
}
    Token() : value(-1), x(0), y(0), is_open(false), is_stopped(false), has_won(false), symbol('!') {}

    // Parameterized constructor
    Token(int v, int x1, int y1, bool open, bool stopped, bool won, char sym)
        : value(v), x(x1), y(y1), is_open(open), is_stopped(stopped), has_won(won), symbol(sym) {}
    ~Token() {}
public:void displayToken() {
        cout <<"Coordinates: " << x << ", " << y << endl;
    }
public:void setIsBlock(bool isblock)
{this->isBlock=isBlock;}
public:void setSymbol(char sym) {
    this->symbol = sym;
}
public:void setCoordinates(int x, int y) {
    this->x=x;
    this->y=y;
}
};

/// Player class definition
class Player {
public:
    // Attributes
    Token* tokens;         // Pointer to the array of tokens
    int hit_rate;          // Hit rate for the player
    int turns_without_six; // Number of turns without rolling a six
    bool has_won;          // Indicates if the player has won
    bool is_active;        // Indicates if the player is still in the game
    std::string colour;    // Color assigned to the player
    int house;
    int num_of_tokens;
    bool hasExtraTurn;
    // Default constructor
    Player() : tokens(nullptr), hit_rate(1), has_won(false), is_active(true), turns_without_six(0), colour("") {}
    // Corrected parameterized constructor in Player class
    Player(char symbol, int num_tokens, int house1) {
        this->num_of_tokens=num_tokens;
        tokens = new Token[num_tokens];  // Allocate memory for tokens
        for (int i = 0; i < num_tokens; i++) {
            tokens[i].symbol = symbol;  // Assign the symbol to each token
        }
        hasExtraTurn=false;
        hit_rate = 0;
        has_won = false;
        is_active = true;
        turns_without_six = 0;
        this->house = house1+1;   // Store the player's house number
        //
        this->tokens = new Token[num_of_tokens];
        char symbol1=' ';
        if (house==1) {symbol1='1';}
        else if (house==2) {symbol1='2';}
        else if (house==3) {symbol1='3';}
        else if (house==4) {symbol1='4';}
        for (int i=0;i<num_of_tokens;i++) {
            tokens[i].setSymbol(symbol1);
            tokens[i].is_at_home=false;
        }
    }
public:bool anytokenOpen() {
    for (int i = 0; i < num_of_tokens; i++) {
        if (tokens[i].is_open) {return true;}
    }
    return false;
}
    Token& displayOpen() {
    for (int i = 0; i < num_of_tokens; i++) {
        // Only display tokens that are open
        if (tokens[i].is_open) {
            cout << i << " : " << "(X:" << tokens[i].x << ", Y:" << tokens[i].y << ")" << endl;
        }
    }
    int choice;
    cout << "Choice: ";
    cin >> choice;

    // Ensure that the selected token is still open
    if (tokens[choice].is_open) {
        return tokens[choice];
    } else {
        cout << "The selected token is no longer available." << endl;
        // Handle the case when a player selects a dead token
    }
}

public:void displayPlayer() {
    cout << "Player Number: "<<house<<endl;
    cout << "Tokens: "<<endl;
    for (int i=0;i<num_of_tokens;i++) {
        cout << tokens[i].symbol<<" ";
    }
}
public:void makeBlockPrev(int x,int y,char symbol) {
    for (int i=0;i<num_of_tokens;i++) {
        if ((tokens[i].x==x)&& (tokens[i].y==y) && (tokens[i].symbol==symbol)) {
            tokens[i].isBlock=true;
        }
    }
}
public:
    bool clearBlockPrev(int x, int y, char symbol) {
        int counter = 0;

        // Count the number of matching tokens at the given position
        for (int i = 0; i < num_of_tokens; i++) {
            if ((tokens[i].symbol == symbol) && (tokens[i].x == x) && (tokens[i].y == y)) {
                counter++;
            }
        }

        // If more than 2 tokens are found, return false
        if (counter > 2) {
            return false;
        }

        // If 2 or fewer tokens are found, clear the block status
        for (int i = 0; i < num_of_tokens; i++) {
            if ((tokens[i].symbol == symbol) && (tokens[i].x == x) && (tokens[i].y == y)) {
                tokens[i].isBlock = false;
            }
        }

        return true;
    }

public:
    bool isPlaceBlock(int x, int y, char symbol) {
        int counter = 0;
        for (int i = 0; i < num_of_tokens; i++) {
            if ((tokens[i].symbol == symbol) && (tokens[i].x == x) && (tokens[i].y == y)) {
                counter++;
            }
        }
        return counter >= 2;
    }

public:int getBlockToken(int x,int y,char symbol) {
    int count=0;
    for (int i=0;i<num_of_tokens;i++) {
        if ((tokens[i].x==x)&& (tokens[i].y==y) && (tokens[i].symbol==symbol)) {
    count++;
        }
    }
    return count;
}
public:bool allHome() {
    int count=0;
    for (int i = 0; i < num_of_tokens; i++) {
        if (tokens[i].is_at_home) {
            count++;
        }
    }
    if (count==num_of_tokens) {
        return true;
    }
    else {
        return false;
    }
}

public:Token& getDeadTokenCoordinate() {
    for (int i = 0; i < num_of_tokens; i++) {
        if (!tokens[i].is_open && !tokens[i].is_at_home) {
            return tokens[i];  // Return the dead token by reference
        }
    }
    throw std::runtime_error("No dead token found.");
}


};

// Functio
//n to handle player turns (presumably with threads)
// Function declaration for player thread
void* player_thread(void* arg);
#endif // PLAYER_THREADS_H
